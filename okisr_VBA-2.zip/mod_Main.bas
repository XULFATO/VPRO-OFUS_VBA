Attribute VB_Name = "mod_Main"
Option Explicit

Private Const NOMBRE_MODULO_TR As String = "OtAflUx01415"

' ============================================================================
' EJECUTAR OFUSCADOR
' ============================================================================
Public Sub EjecutarOfuscador()
    Dim rutaOriginal      As Variant
    Dim rutaDestino       As String
    Dim nombreFich        As String
    Dim wb                As Workbook
    Dim vbc               As Object
    Dim dict              As Object
    Dim i                 As Long
    Dim b                 As Integer
    Dim linea             As String
    Dim lineaOfus         As String
    Dim contenido         As String
    Dim tMod              As Long
    Dim tLin              As Long
    Dim tBot              As Long
    Dim claveUnica        As String
    Dim clavesOrdenadas()  As String
    Dim nombreOriginal     As String
    Dim nLineasMod         As Long
    Dim posExt              As Long
    Dim posSep              As Long
    
    ' -----------------------------------------------------------------------
    ' 1. SELECCION Y VALIDACION
    ' -----------------------------------------------------------------------
    rutaOriginal = Application.GetOpenFilename("Archivos Excel (*.xlsm), *.xlsm")
    ' GetOpenFilename devuelve False (Boolean) al cancelar
    ' Debe ser Variant para detectar False correctamente
    If rutaOriginal = False Then Exit Sub
    
    ' Randomize UNA SOLA VEZ para toda la sesion
    Randomize
    
    claveUnica = GenerarClaveAleatoria(16)
    If Len(claveUnica) = 0 Then
        MsgBox "Error generando clave de cifrado.", vbCritical
        Exit Sub
    End If
    posExt = InStrRev(CStr(rutaOriginal), ".")
    If posExt = 0 Then
        MsgBox "La ruta del archivo no tiene extension.", vbCritical
        Exit Sub
    End If
    rutaDestino = Left(CStr(rutaOriginal), posExt - 1) & "_OFUS.xlsm"
    posSep = Application.Max(InStrRev(rutaDestino, Chr(92)), InStrRev(rutaDestino, "/"))
    nombreFich = Mid(rutaDestino, posSep + 1)
    
    On Error Resume Next
    Err.Clear
    If Dir(rutaDestino) <> "" Then Kill rutaDestino
    If Err.Number <> 0 Then
        On Error GoTo 0
        MsgBox "Cierra el archivo destino antes de continuar.", vbCritical
        Exit Sub
    End If
    Err.Clear
    FileCopy rutaOriginal, rutaDestino
    If Err.Number <> 0 Then
        On Error GoTo 0
        MsgBox "Error al copiar el archivo origen.", vbCritical
        Exit Sub
    End If
    On Error GoTo 0
    On Error GoTo ErrorHandler

    ' -----------------------------------------------------------------------
    ' 2. CONSTRUCCION DEL DICCIONARIO
    ' -----------------------------------------------------------------------
    Set wb   = Workbooks.Open(rutaDestino, UpdateLinks:=0)
    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = 1   ' vbTextCompare: busqueda case-insensitive
    
    Call LlenarDiccionario(wb, dict)
    Err.Clear   ' limpiar errores silenciados dentro de LlenarDiccionario
    
    ' Precalcular array de claves ordenado de mas largo a mas corto.
    ' Se reutiliza en cada llamada a ProcesarLineaMaestra (evita ordenar N veces)
    If dict.Count > 0 Then
        clavesOrdenadas = ObtenerClavesOrdenadas(dict)
    Else
        ReDim clavesOrdenadas(-1)  ' array vacio: UBound=-1, nClaves=0
    End If

    ' -----------------------------------------------------------------------
    ' 3. OFUSCAR MODULO A MODULO
    ' Saltamos los modulos del propio ofuscador para no romperlos
    ' -----------------------------------------------------------------------
    For Each vbc In wb.VBProject.VBComponents
        
        ' Guardar nombre ANTES de renombrar para usarlo en EsModuloOfuscador
        nombreOriginal = ""
        On Error Resume Next
        nombreOriginal = vbc.Name
        On Error GoTo 0
        Err.Clear
        If nombreOriginal = "" Then GoTo SiguienteModulo
        
        ' Renombrar modulo si esta en el diccionario
        If dict.Exists(nombreOriginal) Then
            On Error Resume Next
            vbc.Name = dict(nombreOriginal)
            On Error GoTo 0
            Err.Clear
            tMod = tMod + 1
        End If

        ' Ofuscar solo si NO es modulo del ofuscador (usar nombre ORIGINAL)
        If Not EsModuloOfuscador(nombreOriginal) Then
            nLineasMod = 0
            On Error Resume Next
            nLineasMod = vbc.CodeModule.CountOfLines
            On Error GoTo 0
            Err.Clear
            If nLineasMod > 0 Then
                contenido = ""
                For i = 1 To nLineasMod
                    linea = ""
                    On Error Resume Next
                    linea = vbc.CodeModule.Lines(i, 1)
                    On Error GoTo 0
                    Err.Clear
                    If Trim(linea) = "" Then GoTo SiguienteLineaMod
                    lineaOfus = ProcesarLineaMaestra(linea, dict, claveUnica, clavesOrdenadas)
                    If lineaOfus <> "" Then
                        contenido = contenido & lineaOfus & vbCrLf
                        tLin = tLin + 1
                    End If
SiguienteLineaMod:
                Next i
                
                ' 1-3 bloques de codigo muerto al final
                For b = 1 To Int(Rnd * 3) + 1
                    contenido = contenido & vbCrLf & GenerarBloqueRuido() & vbCrLf
                Next b
                
                If Len(contenido) > 0 Then
                    On Error Resume Next
                    vbc.CodeModule.DeleteLines 1, nLineasMod
                    vbc.CodeModule.AddFromString contenido
                    On Error GoTo 0
                    Err.Clear
                End If
            End If
        End If
        
SiguienteModulo:
    Next vbc

    ' -----------------------------------------------------------------------
    ' 4. SINCRONIZAR BOTONES E INYECTAR TRADUCTOR
    ' -----------------------------------------------------------------------
    tBot = SincronizarBotones(wb, dict, nombreFich)
    Call InyectarModuloTraductor(wb, claveUnica)
    
    wb.Save
    On Error GoTo 0
    
    MsgBox "--- OFUSCACION COMPLETADA ---" & vbCrLf & _
           "Modulos renombrados  : " & tMod & vbCrLf & _
           "Lineas procesadas    : " & tLin & vbCrLf & _
           "Botones actualizados : " & tBot & vbCrLf & _
           "Clave XOR            : " & claveUnica, vbInformation
    Exit Sub

ErrorHandler:
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    On Error GoTo 0
    MsgBox "Error " & Err.Number & ": " & Err.Description, vbCritical, "Ofuscador"
End Sub

' ============================================================================
' MODULOS DEL PROPIO OFUSCADOR — no procesar su codigo interior
' (ya podrian estar renombrados en este punto, se comprueba por nombre nuevo)
' ============================================================================
Private Function EsModuloOfuscador(ByVal nombre As String) As Boolean
    Dim lista As Variant
    lista = Array("mod_Main", "mod_Collector", "mod_Tokenizer", _
                  "mod_Garbage", "mod_Types", "mod_Traductor", _
                  "OtAflUx01415", "Comun_Constantes", "Comun_Buscador", _
                  "ThisWorkbook")
    Dim i As Long
    For i = LBound(lista) To UBound(lista)
        If LCase(nombre) = LCase(lista(i)) Then
            EsModuloOfuscador = True
            Exit Function
        End If
    Next i
    EsModuloOfuscador = False
End Function

' ============================================================================
' INYECTAR MODULO TRADUCTOR — nombre fijo OtAflUx01415
' ============================================================================
Private Sub InyectarModuloTraductor(ByRef wb As Workbook, ByVal clave As String)
    Dim modT As Object
    On Error Resume Next
    wb.VBProject.VBComponents.Remove wb.VBProject.VBComponents(NOMBRE_MODULO_TR)
    On Error GoTo 0
    Err.Clear
    
    On Error Resume Next
    Set modT  = wb.VBProject.VBComponents.Add(1)
    On Error GoTo 0
    Err.Clear
    If modT Is Nothing Then Exit Sub  ' VBProject protegido o error
    modT.Name = NOMBRE_MODULO_TR
    
    ' Descifrado XOR sincronizado con CifrarTextoXOR:
    ' Cifrado j=1 -> k=((1-1) Mod Len)+1=1
    ' Descifrado i=0 -> k=(0 Mod Len)+1=1   OK
    modT.CodeModule.AddFromString _
        "Public Function f_tr(ByVal s As String) As String" & vbCrLf & _
        "    If s = " & Chr(34) & Chr(34) & " Then Exit Function" & vbCrLf & _
        "    Dim v, i, r, cl, k" & vbCrLf & _
        "    cl = " & Chr(34) & clave & Chr(34) & vbCrLf & _
        "    v = Split(s, " & Chr(34) & "," & Chr(34) & ")" & vbCrLf & _
        "    For i = 0 To UBound(v)" & vbCrLf & _
        "        k = (i Mod Len(cl)) + 1" & vbCrLf & _
        "        r = r & Chr(CInt(v(i)) Xor Asc(Mid(cl, k, 1)))" & vbCrLf & _
        "    Next i" & vbCrLf & _
        "    f_tr = r" & vbCrLf & _
        "End Function"
End Sub

' ============================================================================
' GENERAR CLAVE ALEATORIA
' ============================================================================
Private Function GenerarClaveAleatoria(ByVal n As Integer) As String
    Dim i As Integer
    Dim c As String
    Dim r As String
    c = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$"
    For i = 1 To n
        r = r & Mid(c, Int(Len(c) * Rnd + 1), 1)
    Next i
    GenerarClaveAleatoria = r
End Function

' ============================================================================
' SINCRONIZAR BOTONES
' Cubre:
'   A) Shapes con .OnAction  -> botones de formulario clasicos
'   B) OLEObjects            -> ActiveX (CommandButton, etc.)
'   C) Hipervinculos         -> SubAddress con nombre de macro
'
' Los botones creados por codigo con .OnAction = "Macro" quedan resueltos
' por mod_Tokenizer al procesar esa linea. Esta funcion cubre los botones
' ya presentes en la hoja en el momento de ofuscar.
' ============================================================================
Public Function SincronizarBotones(ByRef wb As Workbook, ByRef dict As Object, ByVal nombreFich As String) As Long
    Dim ws          As Worksheet
    Dim shp         As Shape
    Dim ole         As OLEObject
    Dim hv          As Hyperlink
    Dim macroActual As String
    Dim nombreMacro As String
    Dim contador    As Long
    contador = 0
    
    For Each ws In wb.Worksheets
    
        ' A) Shapes con OnAction
        For Each shp In ws.Shapes
            macroActual = ""
            On Error Resume Next
            macroActual = shp.OnAction
            On Error GoTo 0
            Err.Clear
            If macroActual <> "" Then
                nombreMacro = ExtraerNombreMacro(macroActual)
                If dict.Exists(nombreMacro) Then
                    shp.OnAction = "'" & nombreFich & "'!" & CStr(dict(nombreMacro))
                    contador = contador + 1
                End If
            End If
        Next shp
        
        ' B) OLEObjects — ActiveX y otros controles
        For Each ole In ws.OLEObjects
            macroActual = ""
            On Error Resume Next
            macroActual = ole.OnAction
            On Error GoTo 0
            Err.Clear
            If macroActual <> "" Then
                nombreMacro = ExtraerNombreMacro(macroActual)
                If dict.Exists(nombreMacro) Then
                    On Error Resume Next
                    ole.OnAction = "'" & nombreFich & "'!" & CStr(dict(nombreMacro))
                    On Error GoTo 0
                    Err.Clear
                    contador = contador + 1
                End If
            End If
        Next ole
        
        ' C) Hipervinculos con macro en SubAddress
        For Each hv In ws.Hyperlinks
            macroActual = ""
            On Error Resume Next
            macroActual = hv.SubAddress
            On Error GoTo 0
            Err.Clear
            If macroActual <> "" Then
                nombreMacro = ExtraerNombreMacro(macroActual)
                If dict.Exists(nombreMacro) Then
                    hv.SubAddress = CStr(dict(nombreMacro))
                    contador = contador + 1
                End If
            End If
        Next hv
        
    Next ws
    
    SincronizarBotones = contador
End Function

' ============================================================================
' EXTRAER NOMBRE DE MACRO desde cadena OnAction
' Formato A: "NombreMacro"
' Formato B: "'Archivo.xlsm'!NombreMacro"
' ============================================================================
Private Function ExtraerNombreMacro(ByVal onAction As String) As String
    If InStr(onAction, "!") > 0 Then
        ExtraerNombreMacro = Mid(onAction, InStrRev(onAction, "!") + 1)
    Else
        ExtraerNombreMacro = onAction
    End If
End Function
