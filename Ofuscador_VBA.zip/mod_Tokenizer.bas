Attribute VB_Name = "mod_Tokenizer"
Option Explicit

' ============================================================================
' PROCESAR LÍNEA MAESTRA
' Reglas:
'   1. Comentario              → eliminar línea
'   2. Const                   → strings en claro
'   3. OnAction = "..."        → sustituir nombre por espejo en claro (NO XOR)
'   4. Resto de strings        → cifrar XOR
'   5. Código fuera comillas   → reemplazar nombres por espejo
'      (orden largo→corto para evitar sustituciones parciales)
' ============================================================================
Public Function ProcesarLineaMaestra(ByVal linea As String, ByRef dict As Object, ByVal clave As String) As String
    Dim k As Variant, resultado As String, partes() As String, i As Long
    Dim esConstante As Boolean, esOnAction As Boolean
    
    resultado = linea
    
    ' 1. Ignorar comentarios
    If Left(Trim(resultado), 1) = "'" Then
        ProcesarLineaMaestra = ""
        Exit Function
    End If
    
    ' 2. Detectores de línea especial
    esConstante = (InStr(1, LCase(resultado), "const ") > 0)
    esOnAction  = (InStr(1, LCase(resultado), "onaction") > 0 And InStr(resultado, "=") > 0)
    
    ' 3. Dividir por comillas — índices impares = dentro de comillas
    partes = Split(resultado, """")
    
    For i = LBound(partes) To UBound(partes)
    
        If i Mod 2 <> 0 Then
            ' ----------------------------------------------------------------
            ' DENTRO DE COMILLAS
            ' ----------------------------------------------------------------
            If Len(partes(i)) = 0 Then
                ' String vacío: dejar vacío, Join reconstruirá las comillas
                ' al unir con el separador vacío
                ' NOTA: NO añadimos comillas aquí — en modo Join("") los segmentos
                ' pares ya tienen el código y los impares el contenido entre comillas.
                ' Para el string vacío "" simplemente dejamos partes(i) = "" y
                ' al hacer Join quedará: ...partes(par) & "" & partes(par+2)...
                ' pero necesitamos las comillas. Solución: insertar literal "".
                partes(i) = Chr(34) & Chr(34)   ' produce: ""
                
            ElseIf esConstante Then
                partes(i) = Chr(34) & partes(i) & Chr(34)
                
            ElseIf esOnAction Then
                ' OnAction: sustituir nombre por espejo, NO cifrar
                Dim valOA As String, preOA As String, nomOA As String, sepOA As Long
                valOA = partes(i)
                sepOA = InStrRev(valOA, "!")
                If sepOA > 0 Then
                    preOA = Left(valOA, sepOA)
                    nomOA = Mid(valOA, sepOA + 1)
                Else
                    preOA = ""
                    nomOA = valOA
                End If
                If dict.Exists(nomOA) Then nomOA = CStr(dict(nomOA))
                partes(i) = Chr(34) & preOA & nomOA & Chr(34)
                
            Else
                ' String normal: cifrar XOR
                partes(i) = "f_tr(" & Chr(34) & CifrarTextoXOR(partes(i), clave) & Chr(34) & ")"
            End If
            
        Else
            ' ----------------------------------------------------------------
            ' FUERA DE COMILLAS
            ' Reemplazar nombres por espejo.
            ' ORDEN: más largo primero para evitar que un nombre corto
            ' sustituya parte de uno más largo antes de que llegue su turno.
            ' ----------------------------------------------------------------
            Dim claves() As String
            Dim nClaves As Long, m As Long, n As Long, tmp As String
            nClaves = dict.Count
            If nClaves > 0 Then
                ReDim claves(nClaves - 1)
                m = 0
                For Each k In dict.Keys
                    claves(m) = CStr(k)
                    m = m + 1
                Next k
                ' Ordenar de más largo a más corto (burbuja simple)
                For m = 0 To nClaves - 2
                    For n = 0 To nClaves - m - 2
                        If Len(claves(n)) < Len(claves(n + 1)) Then
                            tmp = claves(n)
                            claves(n) = claves(n + 1)
                            claves(n + 1) = tmp
                        End If
                    Next n
                Next m
                ' Sustituir en orden largo→corto
                For m = 0 To nClaves - 1
                    partes(i) = ReemplazarPalabraExacta(partes(i), claves(m), CStr(dict(claves(m))))
                Next m
            End If
        End If
        
    Next i
    
    ' Unir: los segmentos impares ya llevan sus comillas incluidas
    resultado = Join(partes, "")
    
    ' 4. Ruido aleatorio 15%
    ProcesarLineaMaestra = InyectarRuido(resultado)
End Function

' ============================================================================
' CIFRADO XOR
' j=1 → k=1 en cifrado; i=0 → k=(0 Mod Len)+1=1 en descifrado ✓
' ============================================================================
Private Function CifrarTextoXOR(ByVal t As String, ByVal clave As String) As String
    Dim j As Long, k As Long, res As String, cLen As Integer
    cLen = Len(clave)
    For j = 1 To Len(t)
        k = ((j - 1) Mod cLen) + 1
        res = res & (Asc(Mid(t, j, 1)) Xor Asc(Mid(clave, k, 1))) & IIf(j < Len(t), ",", "")
    Next j
    CifrarTextoXOR = res
End Function

' ============================================================================
' REEMPLAZO CON LÍMITES DE PALABRA
' Usa lookahead/lookbehind en lugar de \b para cubrir guiones bajos
' correctamente en VBScript.RegExp (donde \b no considera _ como word char)
' ============================================================================
Private Function ReemplazarPalabraExacta(ByVal texto As String, ByVal viejo As String, ByVal nuevo As String) As String
    Dim RegEx As Object, vEsc As String, c As Variant
    If InStr(1, texto, viejo, vbBinaryCompare) = 0 Then
        ReemplazarPalabraExacta = texto
        Exit Function
    End If
    
    ' Escapar caracteres especiales RegEx
    vEsc = viejo
    For Each c In Array(".", "(", ")", "[", "]", "{", "}", "*", "+", "?", "^", "$", "|", "\")
        vEsc = Replace(vEsc, c, "\" & c)
    Next c
    
    Set RegEx = CreateObject("VBScript.RegExp")
    With RegEx
        .Global     = True
        .IgnoreCase = False
        ' Lookahead/lookbehind cubre _ correctamente, \b no lo hace en VBScript
        .Pattern = "(?<![A-Za-z0-9_])" & vEsc & "(?![A-Za-z0-9_])"
    End With
    ReemplazarPalabraExacta = RegEx.Replace(texto, nuevo)
End Function
