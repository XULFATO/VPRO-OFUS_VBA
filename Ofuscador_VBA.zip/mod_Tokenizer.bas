Attribute VB_Name = "mod_Tokenizer"
Option Explicit

' ============================================================================
' ORDENAR CLAVES DEL DICCIONARIO de mas largo a mas corto
' Se llama UNA SOLA VEZ desde mod_Main antes del bucle de modulos,
' y devuelve un array ordenado que se reutiliza en cada llamada.
' ============================================================================
Public Function ObtenerClavesOrdenadas(ByRef dict As Object) As String()
    Dim claves()  As String
    Dim nClaves   As Long
    Dim k         As Variant
    Dim m         As Long, n As Long
    Dim tmp       As String
    
    nClaves = dict.Count
    ReDim claves(nClaves - 1)
    m = 0
    For Each k In dict.Keys
        claves(m) = CStr(k)
        m = m + 1
    Next k
    
    ' Ordenacion burbuja: mas largo primero
    For m = 0 To nClaves - 2
        For n = 0 To nClaves - m - 2
            If Len(claves(n)) < Len(claves(n + 1)) Then
                tmp        = claves(n)
                claves(n)  = claves(n + 1)
                claves(n + 1) = tmp
            End If
        Next n
    Next m
    
    ObtenerClavesOrdenadas = claves
End Function

' ============================================================================
' PROCESAR LINEA MAESTRA
' Reglas:
'   1. Comentario            -> eliminar linea
'   2. Const                 -> strings en claro
'   3. OnAction = "..."      -> sustituir nombre por espejo en claro (NO XOR)
'   4. Resto de strings      -> cifrar XOR
'   5. Codigo fuera comillas -> reemplazar nombres (array ya ordenado largo->corto)
' ============================================================================
Public Function ProcesarLineaMaestra(ByVal linea As String, ByRef dict As Object, _
                                     ByVal clave As String, ByRef clavesOrdenadas() As String) As String
    ' --- Todas las variables declaradas al inicio del procedimiento ---
    Dim resultado     As String
    Dim partes()      As String
    Dim i             As Long
    Dim m             As Long
    Dim esConstante   As Boolean
    Dim esOnAction    As Boolean
    Dim valOA         As String
    Dim preOA         As String
    Dim nomOA         As String
    Dim sepOA         As Long
    Dim nClaves       As Long
    
    resultado = linea
    
    ' 1. Ignorar comentarios
    If Left(Trim(resultado), 1) = "'" Then
        ProcesarLineaMaestra = ""
        Exit Function
    End If
    
    ' 2. Detectores de linea especial
    esConstante = (InStr(1, LCase(resultado), "const ") > 0)
    esOnAction  = (InStr(1, LCase(resultado), "onaction") > 0 And InStr(resultado, "=") > 0)
    
    ' 3. Dividir por comillas: indices impares = dentro de comillas
    partes = Split(resultado, Chr(34))
    nClaves = UBound(clavesOrdenadas) + 1
    
    For i = LBound(partes) To UBound(partes)
    
        If i Mod 2 <> 0 Then
            ' ----------------------------------------------------------------
            ' DENTRO DE COMILLAS
            ' ----------------------------------------------------------------
            If Len(partes(i)) = 0 Then
                ' String vacio "": restaurar las dos comillas literales
                partes(i) = Chr(34) & Chr(34)
                
            ElseIf esConstante Then
                ' Constante: no cifrar, restaurar comillas
                partes(i) = Chr(34) & partes(i) & Chr(34)
                
            ElseIf esOnAction Then
                ' OnAction: sustituir nombre por espejo, NO cifrar
                valOA = partes(i)
                sepOA = InStrRev(valOA, "!")
                If sepOA > 0 Then
                    preOA = Left(valOA, sepOA)
                    nomOA = Mid(valOA, sepOA + 1)
                Else
                    preOA = ""
                    nomOA = valOA
                End If
                If dict.Exists(nomOA) Then nomOA = CStr(dict(nomOA))
                partes(i) = Chr(34) & preOA & nomOA & Chr(34)
                
            Else
                ' String normal: cifrar XOR
                partes(i) = "f_tr(" & Chr(34) & CifrarTextoXOR(partes(i), clave) & Chr(34) & ")"
            End If
            
        Else
            ' ----------------------------------------------------------------
            ' FUERA DE COMILLAS: reemplazar nombres usando array ya ordenado
            ' ----------------------------------------------------------------
            If nClaves > 0 Then
                For m = 0 To nClaves - 1
                    partes(i) = ReemplazarPalabraExacta(partes(i), clavesOrdenadas(m), _
                                                        CStr(dict(clavesOrdenadas(m))))
                Next m
            End If
        End If
        
    Next i
    
    ' Unir: los segmentos impares ya llevan sus comillas embebidas
    resultado = Join(partes, "")
    
    ' 4. Ruido aleatorio 15%
    ProcesarLineaMaestra = InyectarRuido(resultado)
End Function

' ============================================================================
' CIFRADO XOR
' Cifrado:   j=1 -> k=((1-1) Mod Len)+1 = 1
' Descifrado: i=0 -> k=(0 Mod Len)+1    = 1   SINCRONIZADOS
' ============================================================================
Private Function CifrarTextoXOR(ByVal t As String, ByVal clave As String) As String
    Dim j    As Long
    Dim k    As Long
    Dim res  As String
    Dim cLen As Integer
    cLen = Len(clave)
    For j = 1 To Len(t)
        k   = ((j - 1) Mod cLen) + 1
        res = res & (Asc(Mid(t, j, 1)) Xor Asc(Mid(clave, k, 1))) & IIf(j < Len(t), ",", "")
    Next j
    CifrarTextoXOR = res
End Function

' ============================================================================
' REEMPLAZAR PALABRA EXACTA - VBA puro, sin RegEx
' vbTextCompare: case-insensitive (cubre "ImportarBulk" e "importarbulk")
' Comprueba vecinos para no sustituir subcadenas
' ============================================================================
Private Function ReemplazarPalabraExacta(ByVal texto As String, ByVal viejo As String, ByVal nuevo As String) As String
    Dim resultado      As String
    Dim pos            As Long
    Dim vLen           As Long
    Dim tLen           As Long
    Dim charAntes      As String
    Dim charDespues    As String
    Dim esLimiteAntes  As Boolean
    Dim esLimiteDespues As Boolean
    Dim encontrado     As Long
    Dim posDespues     As Long
    
    ' Salida rapida
    If InStr(1, texto, viejo, vbTextCompare) = 0 Then
        ReemplazarPalabraExacta = texto
        Exit Function
    End If
    
    vLen      = Len(viejo)
    tLen      = Len(texto)
    resultado = ""
    pos       = 1
    
    Do While pos <= tLen
        encontrado = InStr(pos, texto, viejo, vbTextCompare)
        
        If encontrado = 0 Then
            resultado = resultado & Mid(texto, pos)
            Exit Do
        End If
        
        ' Caracter anterior
        If encontrado > 1 Then
            charAntes     = Mid(texto, encontrado - 1, 1)
            esLimiteAntes = Not (charAntes Like "[A-Za-z0-9_]")
        Else
            esLimiteAntes = True
        End If
        
        ' Caracter posterior
        posDespues = encontrado + vLen
        If posDespues <= tLen Then
            charDespues    = Mid(texto, posDespues, 1)
            esLimiteDespues = Not (charDespues Like "[A-Za-z0-9_]")
        Else
            esLimiteDespues = True
        End If
        
        ' Texto antes de la coincidencia
        resultado = resultado & Mid(texto, pos, encontrado - pos)
        
        If esLimiteAntes And esLimiteDespues Then
            resultado = resultado & nuevo
        Else
            ' Subcadena: conservar el fragmento original
            resultado = resultado & Mid(texto, encontrado, vLen)
        End If
        
        pos = encontrado + vLen
    Loop
    
    ReemplazarPalabraExacta = resultado
End Function
