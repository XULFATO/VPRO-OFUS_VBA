Attribute VB_Name = "mod_Main"
Option Explicit

' Nombre fijo del módulo traductor inyectado en el archivo ofuscado
Private Const NOMBRE_MODULO_TR As String = "OtAflUx01415"

' ============================================================================
' EJECUTAR OFUSCADOR
' ============================================================================
Public Sub EjecutarOfuscador()
    Dim rutaOriginal As String, rutaDestino As String, nombreFich As String
    Dim wb As Workbook, vbc As Object, dict As Object
    Dim i As Long, linea As String, lineaOfus As String
    Dim tMod As Long, tLin As Long, tBot As Long
    Dim claveUnica As String
    Dim contenido As String   ' CORRECCIÓN: declarado FUERA del bucle
    Dim b As Integer
    
    ' -----------------------------------------------------------------------
    ' 1. SELECCIÓN Y VALIDACIÓN
    ' -----------------------------------------------------------------------
    rutaOriginal = Application.GetOpenFilename("Archivos Excel (*.xlsm), *.xlsm")
    ' GetOpenFilename devuelve False (Boolean) al cancelar — NO el string "Falso"
    If VarType(rutaOriginal) = vbBoolean Then Exit Sub
    
    ' Randomize UNA SOLA VEZ para toda la sesión
    Randomize
    
    claveUnica  = GenerarClaveAleatoria(16)
    rutaDestino = Left(rutaOriginal, InStrRev(rutaOriginal, ".") - 1) & "_OFUS.xlsm"
    nombreFich  = Mid(rutaDestino, InStrRev(rutaDestino, "\") + 1)
    
    On Error Resume Next
    If Dir(rutaDestino) <> "" Then Kill rutaDestino
    If Err.Number <> 0 Then MsgBox "Cierra el archivo destino antes de continuar.", vbCritical: Exit Sub
    FileCopy rutaOriginal, rutaDestino
    If Err.Number <> 0 Then MsgBox "Error al copiar archivo.", vbCritical: Exit Sub
    On Error GoTo 0

    ' -----------------------------------------------------------------------
    ' 2. CONSTRUCCIÓN DEL DICCIONARIO
    ' -----------------------------------------------------------------------
    Set wb   = Workbooks.Open(rutaDestino)
    Set dict = CreateObject("Scripting.Dictionary")
    
    ' CORRECCIÓN: CompareMode = 1 (vbTextCompare) → búsqueda case-insensitive
    ' Evita que "importarHoy1" y "ImportarHoy1" sean entradas distintas
    dict.CompareMode = 1
    
    Call LlenarDiccionario(wb, dict)

    ' -----------------------------------------------------------------------
    ' 3. OFUSCAR MÓDULO A MÓDULO
    ' -----------------------------------------------------------------------
    For Each vbc In wb.VBProject.VBComponents
        
        ' Renombrar módulo
        If dict.Exists(vbc.Name) Then
            vbc.Name = dict(vbc.Name)
            tMod = tMod + 1
        End If

        ' Ofuscar código
        If vbc.CodeModule.CountOfLines > 0 Then
            
            contenido = ""   ' CORRECCIÓN: resetear en cada iteración
            
            For i = 1 To vbc.CodeModule.CountOfLines
                linea    = vbc.CodeModule.Lines(i, 1)
                lineaOfus = ProcesarLineaMaestra(linea, dict, claveUnica)
                If Trim(lineaOfus) <> "" Then
                    contenido = contenido & lineaOfus & vbCrLf
                    tLin = tLin + 1
                End If
            Next i
            
            ' Añadir 1-3 bloques de código muerto al final
            For b = 1 To Int(Rnd * 3) + 1
                contenido = contenido & vbCrLf & GenerarBloqueRuido() & vbCrLf
            Next b
            
            vbc.CodeModule.DeleteLines 1, vbc.CodeModule.CountOfLines
            vbc.CodeModule.AddFromString contenido
        End If
        
    Next vbc

    ' -----------------------------------------------------------------------
    ' 4. SINCRONIZAR BOTONES E INYECTAR TRADUCTOR
    ' -----------------------------------------------------------------------
    tBot = SincronizarBotones(wb, dict, nombreFich)
    Call InyectarModuloTraductor(wb, claveUnica)
    
    wb.Save
    MsgBox "--- OFUSCACIÓN COMPLETADA ---" & vbCrLf & _
           "Módulos renombrados  : " & tMod & vbCrLf & _
           "Líneas procesadas    : " & tLin & vbCrLf & _
           "Botones actualizados : " & tBot & vbCrLf & _
           "Clave XOR            : " & claveUnica, vbInformation
End Sub

' ============================================================================
' INYECTAR MÓDULO TRADUCTOR — nombre fijo OtAflUx01415
' ============================================================================
Private Sub InyectarModuloTraductor(ByRef wb As Workbook, ByVal clave As String)
    Dim modT As Object
    On Error Resume Next
    wb.VBProject.VBComponents.Remove wb.VBProject.VBComponents(NOMBRE_MODULO_TR)
    On Error GoTo 0
    
    Set modT  = wb.VBProject.VBComponents.Add(1)
    modT.Name = NOMBRE_MODULO_TR
    
    ' Descifrado XOR: i=0 → k=(0 Mod Len)+1=1, sincronizado con cifrado (j=1→k=1) ✓
    modT.CodeModule.AddFromString _
        "Public Function f_tr(ByVal s As String) As String" & vbCrLf & _
        "    If s = """" Then Exit Function" & vbCrLf & _
        "    Dim v, i, r, cl, k" & vbCrLf & _
        "    cl = """ & clave & """" & vbCrLf & _
        "    v = Split(s, "","")" & vbCrLf & _
        "    For i = 0 To UBound(v)" & vbCrLf & _
        "        k = (i Mod Len(cl)) + 1" & vbCrLf & _
        "        r = r & Chr(CInt(v(i)) Xor Asc(Mid(cl, k, 1)))" & vbCrLf & _
        "    Next i" & vbCrLf & _
        "    f_tr = r" & vbCrLf & _
        "End Function"
End Sub

' ============================================================================
' GENERAR CLAVE ALEATORIA
' ============================================================================
Private Function GenerarClaveAleatoria(ByVal n As Integer) As String
    Dim i As Integer, c As String, r As String
    c = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$"
    For i = 1 To n
        r = r & Mid(c, Int(Len(c) * Rnd + 1), 1)
    Next i
    GenerarClaveAleatoria = r
End Function

' ============================================================================
' SINCRONIZAR BOTONES
' Cubre 3 tipos de controles en todas las hojas:
'   A) Shapes con .OnAction  → botones de formulario clásicos
'   B) OLEObjects            → ActiveX (CommandButton, etc.)
'   C) Hipervínculos         → SubAddress con nombre de macro
'
' Los botones creados dinámicamente por código con .OnAction = "Macro"
' quedan resueltos por mod_Tokenizer al procesar esa línea de código.
' Esta función cubre los botones ya presentes en la hoja al ofuscar.
' ============================================================================
Public Function SincronizarBotones(ByRef wb As Workbook, ByRef dict As Object, ByVal nombreFich As String) As Long
    Dim ws As Worksheet, shp As Shape, ole As OLEObject, hv As Hyperlink
    Dim macroActual As String, nombreMacro As String, contador As Long
    contador = 0
    
    For Each ws In wb.Worksheets
    
        ' A) Shapes con OnAction
        For Each shp In ws.Shapes
            On Error Resume Next
            macroActual = shp.OnAction
            On Error GoTo 0
            If macroActual <> "" Then
                nombreMacro = ExtraerNombreMacro(macroActual)
                If dict.Exists(nombreMacro) Then
                    shp.OnAction = "'" & nombreFich & "'!" & CStr(dict(nombreMacro))
                    contador = contador + 1
                End If
            End If
        Next shp
        
        ' B) OLEObjects — ActiveX y otros controles
        For Each ole In ws.OLEObjects
            On Error Resume Next
            macroActual = ole.OnAction
            On Error GoTo 0
            If macroActual <> "" Then
                nombreMacro = ExtraerNombreMacro(macroActual)
                If dict.Exists(nombreMacro) Then
                    On Error Resume Next
                    ole.OnAction = "'" & nombreFich & "'!" & CStr(dict(nombreMacro))
                    On Error GoTo 0
                    contador = contador + 1
                End If
            End If
        Next ole
        
        ' C) Hipervínculos con macro en SubAddress
        For Each hv In ws.Hyperlinks
            On Error Resume Next
            macroActual = hv.SubAddress
            On Error GoTo 0
            If macroActual <> "" Then
                nombreMacro = ExtraerNombreMacro(macroActual)
                If dict.Exists(nombreMacro) Then
                    hv.SubAddress = CStr(dict(nombreMacro))
                    contador = contador + 1
                End If
            End If
        Next hv
        
    Next ws
    
    SincronizarBotones = contador
End Function

' ============================================================================
' EXTRAER NOMBRE DE MACRO desde cadena OnAction
' Formato A: "NombreMacro"
' Formato B: "'Archivo.xlsm'!NombreMacro"
' ============================================================================
Private Function ExtraerNombreMacro(ByVal onAction As String) As String
    If InStr(onAction, "!") > 0 Then
        ExtraerNombreMacro = Mid(onAction, InStrRev(onAction, "!") + 1)
    Else
        ExtraerNombreMacro = onAction
    End If
End Function
