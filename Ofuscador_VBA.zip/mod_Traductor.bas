Attribute VB_Name = "mod_Traductor"
Option Explicit

' ============================================================================
' FUNCIÓN DE TRADUCCIÓN — VERSIÓN DESARROLLO (solo para pruebas locales)
'
' IMPORTANTE: Esta versión NO se usa en archivos ofuscados.
' El ofuscador inyecta dinámicamente el módulo "OtAflUx01415" con XOR + clave
' única por sesión. Esta función es solo referencia; usa desplazamiento fijo
' de -7 en lugar de XOR, por lo que NO descifra archivos ya ofuscados.
' ============================================================================
Public Function f_tr(ByVal s As String) As String
    On Error Resume Next
    Dim v As Variant, i As Long, r As String
    
    If s = "" Then Exit Function
    r = ""
    v = Split(s, ",")
    For i = LBound(v) To UBound(v)
        r = r & Chr(CInt(v(i)) - 7)
    Next i
    f_tr = r
End Function
