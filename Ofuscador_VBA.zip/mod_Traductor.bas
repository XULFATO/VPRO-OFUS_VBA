Attribute VB_Name = "mod_Traductor"
Option Explicit

' ============================================================================
' FUNCION DE TRADUCCION - VERSION DESARROLLO (solo pruebas locales)
' NO se usa en archivos ofuscados. El ofuscador inyecta OtAflUx01415 con
' XOR + clave unica. Esta version usa desplazamiento fijo -7, NO descifra
' archivos ya ofuscados con XOR.
' ============================================================================
Public Function f_tr(ByVal s As String) As String
    On Error Resume Next
    Dim v As Variant, i As Long, r As String
    If s = "" Then Exit Function
    r = ""
    v = Split(s, ",")
    For i = LBound(v) To UBound(v)
        r = r & Chr(CInt(v(i)) - 7)
    Next i
    f_tr = r
End Function
