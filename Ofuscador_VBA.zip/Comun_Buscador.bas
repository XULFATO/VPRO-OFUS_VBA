Attribute VB_Name = "Comun_Buscador"
Option Explicit

' ============================================================================
' MÓDULO DE RESERVA
' f_tr se define únicamente en mod_Traductor (desarrollo) y se inyecta como
' OtAflUx01415 (producción). No se declara aquí para evitar duplicados.
' ============================================================================
