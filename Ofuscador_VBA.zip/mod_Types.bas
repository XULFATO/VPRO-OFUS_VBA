Attribute VB_Name = "mod_Types"
Option Explicit

' ============================================================================
' TIPO DE DATO: SEGMENTO
' ============================================================================
Public Type Segmento
    contenido As String
    EsCodigo  As Boolean
End Type
